###############################################################################
# Novu — Production environment (ap-south-1)
# Wires together: network → secrets → data → edge → compute → observability
###############################################################################

terraform {
  required_version = ">= 1.6"

  required_providers {
    aws    = { source = "hashicorp/aws",    version = "~> 5.60" }
    random = { source = "hashicorp/random", version = "~> 3.6" }
  }

  backend "s3" {
    bucket         = "REPLACE-ME-tf-state-novu"   # team-controlled bucket
    key            = "envs/prd/terraform.tfstate"
    region         = "ap-south-1"
    dynamodb_table = "REPLACE-ME-tf-locks"
    encrypt        = true
  }
}

provider "aws" {
  region = "ap-south-1"
  default_tags {
    tags = local.tags
  }
}

locals {
  env         = "prd"
  name_prefix = "novu-prd"
  hostname    = "novu.example.com"
  tags = {
    Environment = "prd"
    Project     = "novu-notifications"
    Owner       = "platform-engineering"
    CostCentre  = "TBD"
    DataClass   = "internal-restricted"
    ManagedBy   = "terraform"
  }
}

variable "alarm_email"        { type = string }
variable "route53_zone_id"    { type = string }
variable "bridge_image"       { type = string  default = "REPLACE_ME-ecr-uri:tag" }

###############################################################################
# Network
###############################################################################
module "network" {
  source      = "../../modules/network"
  name_prefix = local.name_prefix
  cidr        = "10.40.0.0/16"
  azs         = ["ap-south-1a", "ap-south-1b"]
  tags        = local.tags
}

###############################################################################
# Secrets
###############################################################################
module "secrets" {
  source      = "../../modules/secrets"
  name_prefix = local.name_prefix
  environment = local.env
  tags        = local.tags
}

###############################################################################
# Edge — ALB + target groups + WAF + S3 (need this before compute for TG ARNs)
###############################################################################
module "edge" {
  source              = "../../modules/edge"
  name_prefix         = local.name_prefix
  vpc_id              = module.network.vpc_id
  public_subnet_ids   = module.network.public_subnet_ids
  kms_key_arn         = module.secrets.kms_key_arn
  hostname            = local.hostname
  route53_zone_id     = var.route53_zone_id
  trigger_rate_limit_per_5min_per_ip = 600
  tags                = local.tags
}

###############################################################################
# Data — DocumentDB + ElastiCache (queue + cache)
###############################################################################
data "aws_secretsmanager_secret_version" "redis_queue" {
  secret_id = module.secrets.secret_arns.redis_queue
}
data "aws_secretsmanager_secret_version" "redis_cache" {
  secret_id = module.secrets.secret_arns.redis_cache
}

module "data" {
  source                = "../../modules/data"
  name_prefix           = local.name_prefix
  vpc_id                = module.network.vpc_id
  data_subnet_ids       = module.network.data_subnet_ids
  app_security_group_id = module.compute.tasks_security_group
  kms_key_arn           = module.secrets.kms_key_arn
  redis_auth_queue      = data.aws_secretsmanager_secret_version.redis_queue.secret_string
  redis_auth_cache      = data.aws_secretsmanager_secret_version.redis_cache.secret_string
  docdb_instance_class  = "db.r6g.large"
  docdb_instance_count  = 2
  redis_node_type       = "cache.t4g.medium"
  tags                  = local.tags
}

###############################################################################
# Compute — ECS cluster + 5 services
###############################################################################
module "compute" {
  source                     = "../../modules/compute"
  name_prefix                = local.name_prefix
  vpc_id                     = module.network.vpc_id
  app_subnet_ids             = module.network.app_subnet_ids
  alb_security_group_id      = module.edge.alb_security_group_id
  kms_key_arn                = module.secrets.kms_key_arn
  secret_arns                = module.secrets.secret_arns
  image_repository           = "ghcr.io/novuhq/novu"
  novu_version               = "2.3.0"
  bridge_image               = var.bridge_image
  host_name                  = "https://${local.hostname}"
  front_base_url             = "https://${local.hostname}"
  api_root_url               = "https://${local.hostname}/api"
  ws_public_url              = "wss://${local.hostname}/ws"
  bridge_public_url          = "https://${local.hostname}/bridge"
  api_target_group_arn       = module.edge.api_target_group_arn
  ws_target_group_arn        = module.edge.ws_target_group_arn
  dashboard_target_group_arn = module.edge.dashboard_target_group_arn
  bridge_target_group_arn    = module.edge.bridge_target_group_arn
  s3_bucket_arn              = module.edge.s3_bucket_arn
  log_retention_days         = 90
  tags                       = local.tags
}

###############################################################################
# Observability — alarms
###############################################################################
module "observability" {
  source           = "../../modules/observability"
  name_prefix      = local.name_prefix
  alb_arn_suffix   = trimprefix(module.edge.alb_arn, "arn:aws:elasticloadbalancing:ap-south-1:")
  ecs_cluster_name = module.compute.cluster_name
  service_names    = module.compute.service_names
  kms_key_arn      = module.secrets.kms_key_arn
  alarm_email      = var.alarm_email
  tags             = local.tags
}

###############################################################################
# Outputs
###############################################################################
output "novu_url"        { value = "https://${local.hostname}" }
output "vpc_id"          { value = module.network.vpc_id }
output "ecs_cluster"     { value = module.compute.cluster_name }
output "alb_dns_name"    { value = module.edge.alb_dns_name }
output "kms_key_arn"     { value = module.secrets.kms_key_arn }
output "secret_arns"     { value = module.secrets.secret_arns  sensitive = true }
output "docdb_endpoint"  { value = module.data.docdb_endpoint }
output "redis_queue"     { value = module.data.redis_queue_endpoint }
output "redis_cache"     { value = module.data.redis_cache_endpoint }
