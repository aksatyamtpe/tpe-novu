###############################################################################
# Observability module — alarms aligned with the runbook (Section 9.1 / 31.2)
###############################################################################

terraform {
  required_version = ">= 1.6"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.60" }
  }
}

variable "name_prefix"     { type = string }
variable "alb_arn_suffix"  { type = string }
variable "ecs_cluster_name" { type = string }
variable "service_names"   { type = map(string) }
variable "kms_key_arn"     { type = string }
variable "alarm_email"     { type = string }
variable "tags"            { type = map(string)  default = {} }

resource "aws_sns_topic" "alarms" {
  name              = "${var.name_prefix}-alarms"
  kms_master_key_id = var.kms_key_arn
  tags              = var.tags
}

resource "aws_sns_topic_subscription" "email" {
  topic_arn = aws_sns_topic.alarms.arn
  protocol  = "email"
  endpoint  = var.alarm_email
}

# api 5xx rate (P1)
resource "aws_cloudwatch_metric_alarm" "api_5xx" {
  alarm_name          = "${var.name_prefix}-api-5xx-rate"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 5
  metric_name         = "HTTPCode_Target_5XX_Count"
  namespace           = "AWS/ApplicationELB"
  period              = 60
  statistic           = "Sum"
  threshold           = 10
  treat_missing_data  = "notBreaching"
  dimensions          = { LoadBalancer = var.alb_arn_suffix }
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
  tags                = var.tags
}

# api p95 latency (P2)
resource "aws_cloudwatch_metric_alarm" "api_latency_p95" {
  alarm_name          = "${var.name_prefix}-api-p95-latency"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 5
  metric_name         = "TargetResponseTime"
  namespace           = "AWS/ApplicationELB"
  period              = 60
  extended_statistic  = "p95"
  threshold           = 0.8           # 800 ms
  dimensions          = { LoadBalancer = var.alb_arn_suffix }
  alarm_actions       = [aws_sns_topic.alarms.arn]
  tags                = var.tags
}

# Worker memory pressure (P2)
resource "aws_cloudwatch_metric_alarm" "worker_memory" {
  alarm_name          = "${var.name_prefix}-worker-mem"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 3
  metric_name         = "MemoryUtilization"
  namespace           = "AWS/ECS"
  period              = 60
  statistic           = "Average"
  threshold           = 85
  dimensions = {
    ClusterName = var.ecs_cluster_name
    ServiceName = var.service_names.worker
  }
  alarm_actions = [aws_sns_topic.alarms.arn]
  tags          = var.tags
}

# ws connection count placeholder — needs a custom metric published by ws task
# (counts are not exposed natively). Wire when the metric publisher is in place.

# Container Insights — log subscription filter for worker error patterns
resource "aws_cloudwatch_log_metric_filter" "worker_failed_jobs" {
  name           = "${var.name_prefix}-worker-failed-jobs"
  log_group_name = "/ecs/${var.name_prefix}/worker"
  pattern        = "{ $.level = \"error\" && $.msg = *failed* }"

  metric_transformation {
    name      = "WorkerFailedJobs"
    namespace = "Novu/${var.name_prefix}"
    value     = "1"
  }
}

resource "aws_cloudwatch_metric_alarm" "worker_failed_jobs" {
  alarm_name          = "${var.name_prefix}-worker-failed-jobs"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 5
  metric_name         = "WorkerFailedJobs"
  namespace           = "Novu/${var.name_prefix}"
  period              = 60
  statistic           = "Sum"
  threshold           = 50
  alarm_actions       = [aws_sns_topic.alarms.arn]
  tags                = var.tags
}

output "sns_topic_arn" { value = aws_sns_topic.alarms.arn }
