###############################################################################
# Secrets module — KMS CMK + Secrets Manager entries for Novu
###############################################################################

terraform {
  required_version = ">= 1.6"
  required_providers {
    aws    = { source = "hashicorp/aws", version = "~> 5.60" }
    random = { source = "hashicorp/random", version = "~> 3.6" }
  }
}

variable "name_prefix" { type = string }
variable "environment" { type = string }
variable "tags"        { type = map(string)  default = {} }

###############################################################################
# KMS CMK
###############################################################################
resource "aws_kms_key" "this" {
  description             = "KMS CMK for Novu ${var.environment}"
  deletion_window_in_days = 30
  enable_key_rotation     = true
  tags                    = merge(var.tags, { Name = "${var.name_prefix}-cmk" })
}

resource "aws_kms_alias" "this" {
  name          = "alias/${var.name_prefix}"
  target_key_id = aws_kms_key.this.key_id
}

###############################################################################
# Generated secrets — JWT, STORE_ENCRYPTION_KEY (32 chars exact), NOVU_SECRET_KEY
###############################################################################
resource "random_password" "jwt_secret" {
  length  = 64
  special = false
}

resource "random_password" "store_encryption_key" {
  length  = 32
  special = false
  upper   = true
  lower   = true
  numeric = true
}

resource "random_password" "novu_secret_key" {
  length  = 64
  special = false
}

resource "random_password" "redis_queue" {
  length  = 32
  special = false
}

resource "random_password" "redis_cache" {
  length  = 32
  special = false
}

resource "random_password" "mongo_app" {
  length  = 32
  special = false
}

###############################################################################
# Secrets Manager entries
###############################################################################
resource "aws_secretsmanager_secret" "jwt" {
  name       = "${var.name_prefix}/jwt-secret"
  kms_key_id = aws_kms_key.this.arn
  tags       = var.tags
}
resource "aws_secretsmanager_secret_version" "jwt" {
  secret_id     = aws_secretsmanager_secret.jwt.id
  secret_string = random_password.jwt_secret.result
}

resource "aws_secretsmanager_secret" "store_key" {
  name       = "${var.name_prefix}/store-encryption-key"
  kms_key_id = aws_kms_key.this.arn
  tags       = var.tags
  description = "EXACTLY 32 chars. Rotation requires re-encrypting all integration credentials."
}
resource "aws_secretsmanager_secret_version" "store_key" {
  secret_id     = aws_secretsmanager_secret.store_key.id
  secret_string = random_password.store_encryption_key.result
}

resource "aws_secretsmanager_secret" "novu_key" {
  name       = "${var.name_prefix}/novu-secret-key"
  kms_key_id = aws_kms_key.this.arn
  tags       = var.tags
}
resource "aws_secretsmanager_secret_version" "novu_key" {
  secret_id     = aws_secretsmanager_secret.novu_key.id
  secret_string = random_password.novu_secret_key.result
}

resource "aws_secretsmanager_secret" "redis_queue" {
  name       = "${var.name_prefix}/redis-queue-auth"
  kms_key_id = aws_kms_key.this.arn
  tags       = var.tags
}
resource "aws_secretsmanager_secret_version" "redis_queue" {
  secret_id     = aws_secretsmanager_secret.redis_queue.id
  secret_string = random_password.redis_queue.result
}

resource "aws_secretsmanager_secret" "redis_cache" {
  name       = "${var.name_prefix}/redis-cache-auth"
  kms_key_id = aws_kms_key.this.arn
  tags       = var.tags
}
resource "aws_secretsmanager_secret_version" "redis_cache" {
  secret_id     = aws_secretsmanager_secret.redis_cache.id
  secret_string = random_password.redis_cache.result
}

resource "aws_secretsmanager_secret" "mongo" {
  name       = "${var.name_prefix}/mongo-connection"
  kms_key_id = aws_kms_key.this.arn
  tags       = var.tags
  description = "MongoDB connection URL for Novu app. Populated manually after Atlas / DocumentDB provisioning."
}

###############################################################################
# Provider keys (placeholders — populated manually per environment)
###############################################################################
resource "aws_secretsmanager_secret" "ses" {
  name        = "${var.name_prefix}/provider-ses"
  kms_key_id  = aws_kms_key.this.arn
  tags        = var.tags
  description = "SES IAM access key + secret. Manual entry after IAM user creation."
}

resource "aws_secretsmanager_secret" "msg91" {
  name        = "${var.name_prefix}/provider-msg91"
  kms_key_id  = aws_kms_key.this.arn
  tags        = var.tags
  description = "MSG91 auth key, sender ID, DLT principal entity ID."
}

resource "aws_secretsmanager_secret" "fcm" {
  name        = "${var.name_prefix}/provider-fcm"
  kms_key_id  = aws_kms_key.this.arn
  tags        = var.tags
  description = "FCM service account JSON. Paste full JSON as secret value."
}

###############################################################################
# Outputs
###############################################################################
output "kms_key_arn"           { value = aws_kms_key.this.arn }
output "kms_key_id"            { value = aws_kms_key.this.key_id }
output "secret_arns" {
  value = {
    jwt          = aws_secretsmanager_secret.jwt.arn
    store_key    = aws_secretsmanager_secret.store_key.arn
    novu_key     = aws_secretsmanager_secret.novu_key.arn
    redis_queue  = aws_secretsmanager_secret.redis_queue.arn
    redis_cache  = aws_secretsmanager_secret.redis_cache.arn
    mongo        = aws_secretsmanager_secret.mongo.arn
    ses          = aws_secretsmanager_secret.ses.arn
    msg91        = aws_secretsmanager_secret.msg91.arn
    fcm          = aws_secretsmanager_secret.fcm.arn
  }
}
