###############################################################################
# Data module — DocumentDB cluster + ElastiCache (queue + cache replication groups)
#
# Note: this module provisions DocumentDB. If MongoDB Atlas is preferred,
# replace this with a `mongodbatlas_cluster` block from the MongoDB Atlas
# Terraform provider — connection-string output stays the same shape.
###############################################################################

terraform {
  required_version = ">= 1.6"
  required_providers {
    aws    = { source = "hashicorp/aws", version = "~> 5.60" }
    random = { source = "hashicorp/random", version = "~> 3.6" }
  }
}

variable "name_prefix"           { type = string }
variable "vpc_id"                { type = string }
variable "data_subnet_ids"       { type = list(string) }
variable "app_security_group_id" { type = string }
variable "kms_key_arn"           { type = string }
variable "docdb_instance_class"  { type = string  default = "db.r6g.large" }
variable "docdb_instance_count"  { type = number  default = 2 }
variable "redis_node_type"       { type = string  default = "cache.t4g.medium" }
variable "redis_auth_queue"      { type = string  sensitive = true }
variable "redis_auth_cache"      { type = string  sensitive = true }
variable "tags"                  { type = map(string)  default = {} }

###############################################################################
# DocumentDB
###############################################################################
resource "random_password" "docdb_master" {
  length  = 24
  special = false
}

resource "aws_docdb_subnet_group" "this" {
  name       = "${var.name_prefix}-docdb-subnets"
  subnet_ids = var.data_subnet_ids
  tags       = var.tags
}

resource "aws_security_group" "docdb" {
  name        = "${var.name_prefix}-docdb-sg"
  description = "DocumentDB access from app tier"
  vpc_id      = var.vpc_id

  ingress {
    from_port       = 27017
    to_port         = 27017
    protocol        = "tcp"
    security_groups = [var.app_security_group_id]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = var.tags
}

resource "aws_docdb_cluster_parameter_group" "this" {
  family      = "docdb5.0"
  name        = "${var.name_prefix}-docdb-params"
  description = "Novu DocumentDB parameters"

  parameter {
    name  = "tls"
    value = "enabled"
  }
  parameter {
    name  = "audit_logs"
    value = "enabled"
  }
  tags = var.tags
}

resource "aws_docdb_cluster" "this" {
  cluster_identifier              = "${var.name_prefix}-docdb"
  engine                          = "docdb"
  engine_version                  = "5.0.0"
  master_username                 = "novu_root"
  master_password                 = random_password.docdb_master.result
  db_subnet_group_name            = aws_docdb_subnet_group.this.name
  vpc_security_group_ids          = [aws_security_group.docdb.id]
  storage_encrypted               = true
  kms_key_id                      = var.kms_key_arn
  backup_retention_period         = 35
  preferred_backup_window         = "21:00-22:00"   # UTC = 02:30 IST start
  db_cluster_parameter_group_name = aws_docdb_cluster_parameter_group.this.name
  deletion_protection             = true
  enabled_cloudwatch_logs_exports = ["audit", "profiler"]
  skip_final_snapshot             = false
  final_snapshot_identifier       = "${var.name_prefix}-docdb-final"

  tags = var.tags
}

resource "aws_docdb_cluster_instance" "this" {
  count              = var.docdb_instance_count
  identifier         = "${var.name_prefix}-docdb-${count.index}"
  cluster_identifier = aws_docdb_cluster.this.id
  instance_class     = var.docdb_instance_class
  tags               = var.tags
}

###############################################################################
# ElastiCache — queue (AOF on, noeviction)
###############################################################################
resource "aws_elasticache_subnet_group" "this" {
  name       = "${var.name_prefix}-cache-subnets"
  subnet_ids = var.data_subnet_ids
  tags       = var.tags
}

resource "aws_security_group" "redis" {
  name        = "${var.name_prefix}-redis-sg"
  description = "Redis access from app tier"
  vpc_id      = var.vpc_id

  ingress {
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = [var.app_security_group_id]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = var.tags
}

resource "aws_elasticache_parameter_group" "queue" {
  name   = "${var.name_prefix}-queue-params"
  family = "redis7"

  parameter {
    name  = "appendonly"
    value = "yes"
  }
  parameter {
    name  = "maxmemory-policy"
    value = "noeviction"
  }
  tags = var.tags
}

resource "aws_elasticache_replication_group" "queue" {
  replication_group_id        = "${var.name_prefix}-queue"
  description                 = "Novu BullMQ queue"
  engine                      = "redis"
  engine_version              = "7.1"
  node_type                   = var.redis_node_type
  parameter_group_name        = aws_elasticache_parameter_group.queue.name
  num_cache_clusters          = 2
  multi_az_enabled            = true
  automatic_failover_enabled  = true
  subnet_group_name           = aws_elasticache_subnet_group.this.name
  security_group_ids          = [aws_security_group.redis.id]
  at_rest_encryption_enabled  = true
  kms_key_id                  = var.kms_key_arn
  transit_encryption_enabled  = true
  auth_token                  = var.redis_auth_queue
  snapshot_retention_limit    = 7
  snapshot_window             = "21:00-22:00"
  apply_immediately           = false
  tags                        = var.tags
}

###############################################################################
# ElastiCache — cache (LRU, persistence off)
###############################################################################
resource "aws_elasticache_parameter_group" "cache" {
  name   = "${var.name_prefix}-cache-params"
  family = "redis7"

  parameter {
    name  = "maxmemory-policy"
    value = "allkeys-lru"
  }
  tags = var.tags
}

resource "aws_elasticache_replication_group" "cache" {
  replication_group_id        = "${var.name_prefix}-cache"
  description                 = "Novu DAL + widget cache"
  engine                      = "redis"
  engine_version              = "7.1"
  node_type                   = var.redis_node_type
  parameter_group_name        = aws_elasticache_parameter_group.cache.name
  num_cache_clusters          = 2
  multi_az_enabled            = true
  automatic_failover_enabled  = true
  subnet_group_name           = aws_elasticache_subnet_group.this.name
  security_group_ids          = [aws_security_group.redis.id]
  at_rest_encryption_enabled  = true
  kms_key_id                  = var.kms_key_arn
  transit_encryption_enabled  = true
  auth_token                  = var.redis_auth_cache
  apply_immediately           = false
  tags                        = var.tags
}

###############################################################################
# Outputs
###############################################################################
output "docdb_endpoint"        { value = aws_docdb_cluster.this.endpoint }
output "docdb_reader_endpoint" { value = aws_docdb_cluster.this.reader_endpoint }
output "docdb_master_password" { value = random_password.docdb_master.result  sensitive = true }
output "redis_queue_endpoint"  { value = aws_elasticache_replication_group.queue.primary_endpoint_address }
output "redis_cache_endpoint"  { value = aws_elasticache_replication_group.cache.primary_endpoint_address }
output "redis_security_group_id" { value = aws_security_group.redis.id }
output "docdb_security_group_id" { value = aws_security_group.docdb.id }
