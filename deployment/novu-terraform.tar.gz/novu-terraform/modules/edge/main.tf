###############################################################################
# Edge module — ALB, target groups, ACM cert, WAF, S3 bucket, S3 access logs
###############################################################################

terraform {
  required_version = ">= 1.6"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.60" }
  }
}

variable "name_prefix"          { type = string }
variable "vpc_id"               { type = string }
variable "public_subnet_ids"    { type = list(string) }
variable "kms_key_arn"          { type = string }
variable "hostname"             { type = string }
variable "route53_zone_id"      { type = string }
variable "tags"                 { type = map(string)  default = {} }
variable "trigger_rate_limit_per_5min_per_ip" { type = number  default = 600 }

###############################################################################
# ACM certificate
###############################################################################
resource "aws_acm_certificate" "this" {
  domain_name       = var.hostname
  validation_method = "DNS"
  lifecycle { create_before_destroy = true }
  tags              = var.tags
}

resource "aws_route53_record" "cert_validation" {
  for_each = {
    for dvo in aws_acm_certificate.this.domain_validation_options : dvo.domain_name => {
      name  = dvo.resource_record_name
      value = dvo.resource_record_value
      type  = dvo.resource_record_type
    }
  }
  zone_id = var.route53_zone_id
  name    = each.value.name
  type    = each.value.type
  records = [each.value.value]
  ttl     = 60
}

resource "aws_acm_certificate_validation" "this" {
  certificate_arn         = aws_acm_certificate.this.arn
  validation_record_fqdns = [for r in aws_route53_record.cert_validation : r.fqdn]
}

###############################################################################
# ALB security group
###############################################################################
resource "aws_security_group" "alb" {
  name        = "${var.name_prefix}-alb-sg"
  description = "Public ALB"
  vpc_id      = var.vpc_id

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = var.tags
}

###############################################################################
# ALB access logs bucket
###############################################################################
resource "aws_s3_bucket" "alb_logs" {
  bucket = "${var.name_prefix}-alb-logs"
  tags   = var.tags
}

resource "aws_s3_bucket_versioning" "alb_logs" {
  bucket = aws_s3_bucket.alb_logs.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_public_access_block" "alb_logs" {
  bucket                  = aws_s3_bucket.alb_logs.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_lifecycle_configuration" "alb_logs" {
  bucket = aws_s3_bucket.alb_logs.id
  rule {
    id     = "archive"
    status = "Enabled"
    transition {
      days          = 30
      storage_class = "GLACIER_IR"
    }
    expiration { days = 2555 }   # 7 years for compliance
  }
}

data "aws_elb_service_account" "main" {}

resource "aws_s3_bucket_policy" "alb_logs" {
  bucket = aws_s3_bucket.alb_logs.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { AWS = data.aws_elb_service_account.main.arn }
      Action    = "s3:PutObject"
      Resource  = "${aws_s3_bucket.alb_logs.arn}/AWSLogs/*"
    }]
  })
}

###############################################################################
# ALB
###############################################################################
resource "aws_lb" "this" {
  name               = "${var.name_prefix}-alb"
  internal           = false
  load_balancer_type = "application"
  subnets            = var.public_subnet_ids
  security_groups    = [aws_security_group.alb.id]

  enable_deletion_protection       = true
  enable_cross_zone_load_balancing = true
  drop_invalid_header_fields       = true

  access_logs {
    bucket  = aws_s3_bucket.alb_logs.bucket
    enabled = true
  }
  tags = var.tags
}

###############################################################################
# Target groups — one per service
###############################################################################
resource "aws_lb_target_group" "api" {
  name        = "${var.name_prefix}-api"
  port        = 3000
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_id

  health_check {
    path                = "/v1/health-check"
    matcher             = "200"
    healthy_threshold   = 2
    unhealthy_threshold = 3
    interval            = 30
    timeout             = 5
  }

  deregistration_delay = 30
  tags                 = var.tags
}

resource "aws_lb_target_group" "ws" {
  name        = "${var.name_prefix}-ws"
  port        = 3002
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_id

  health_check {
    path    = "/health-check"
    matcher = "200"
  }

  stickiness {
    type            = "lb_cookie"
    cookie_duration = 3600
    enabled         = true
  }
  tags = var.tags
}

resource "aws_lb_target_group" "dashboard" {
  name        = "${var.name_prefix}-dashboard"
  port        = 4000
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_id
  health_check {
    path    = "/"
    matcher = "200,302"
  }
  tags = var.tags
}

resource "aws_lb_target_group" "bridge" {
  name        = "${var.name_prefix}-bridge"
  port        = 4001
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_id
  health_check {
    path    = "/api/novu"
    matcher = "200"
  }
  tags = var.tags
}

###############################################################################
# Listeners
###############################################################################
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.this.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type = "redirect"
    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.this.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = aws_acm_certificate_validation.this.certificate_arn

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.dashboard.arn
  }
}

resource "aws_lb_listener_rule" "api" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 10
  condition {
    path_pattern { values = ["/api/*", "/v1/*"] }
  }
  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.api.arn
  }
}

resource "aws_lb_listener_rule" "ws" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 20
  condition {
    path_pattern { values = ["/ws/*"] }
  }
  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.ws.arn
  }
}

resource "aws_lb_listener_rule" "bridge" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 30
  condition {
    path_pattern { values = ["/bridge/*"] }
  }
  # In production, also restrict by source IP — Bridge endpoint should not be public
  condition {
    source_ip {
      values = var.bridge_allowed_cidrs
    }
  }
  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.bridge.arn
  }
}

variable "bridge_allowed_cidrs" {
  type    = list(string)
  default = ["10.0.0.0/8"]    # corporate VPC; tune per deployment
}

###############################################################################
# Route 53 record
###############################################################################
resource "aws_route53_record" "alias" {
  zone_id = var.route53_zone_id
  name    = var.hostname
  type    = "A"
  alias {
    name                   = aws_lb.this.dns_name
    zone_id                = aws_lb.this.zone_id
    evaluate_target_health = true
  }
}

###############################################################################
# WAF — AWS Managed Rules + custom rate limit
###############################################################################
resource "aws_wafv2_web_acl" "this" {
  name        = "${var.name_prefix}-waf"
  description = "Novu front-door WAF"
  scope       = "REGIONAL"

  default_action { allow {} }

  rule {
    name     = "AWSManagedRulesCommonRuleSet"
    priority = 1
    override_action { none {} }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesCommonRuleSet"
        vendor_name = "AWS"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${var.name_prefix}-waf-common"
      sampled_requests_enabled   = true
    }
  }

  rule {
    name     = "AWSManagedRulesKnownBadInputsRuleSet"
    priority = 2
    override_action { none {} }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesKnownBadInputsRuleSet"
        vendor_name = "AWS"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${var.name_prefix}-waf-knownbad"
      sampled_requests_enabled   = true
    }
  }

  rule {
    name     = "AWSManagedRulesAmazonIpReputationList"
    priority = 3
    override_action { none {} }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesAmazonIpReputationList"
        vendor_name = "AWS"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${var.name_prefix}-waf-iprep"
      sampled_requests_enabled   = true
    }
  }

  rule {
    name     = "TriggerEndpointRateLimit"
    priority = 100
    action { block {} }
    statement {
      rate_based_statement {
        limit              = var.trigger_rate_limit_per_5min_per_ip
        aggregate_key_type = "IP"
        scope_down_statement {
          byte_match_statement {
            field_to_match { uri_path {} }
            positional_constraint = "STARTS_WITH"
            search_string         = "/v1/events/trigger"
            text_transformation {
              priority = 0
              type     = "NONE"
            }
          }
        }
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "${var.name_prefix}-waf-rate"
      sampled_requests_enabled   = true
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "${var.name_prefix}-waf"
    sampled_requests_enabled   = true
  }

  tags = var.tags
}

resource "aws_wafv2_web_acl_association" "this" {
  resource_arn = aws_lb.this.arn
  web_acl_arn  = aws_wafv2_web_acl.this.arn
}

###############################################################################
# S3 bucket for Novu attachments / layouts
###############################################################################
resource "aws_s3_bucket" "novu" {
  bucket = "${var.name_prefix}-attachments"
  tags   = var.tags
}

resource "aws_s3_bucket_versioning" "novu" {
  bucket = aws_s3_bucket.novu.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_public_access_block" "novu" {
  bucket                  = aws_s3_bucket.novu.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "novu" {
  bucket = aws_s3_bucket.novu.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = var.kms_key_arn
    }
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "novu" {
  bucket = aws_s3_bucket.novu.id
  rule {
    id     = "tier-noncurrent"
    status = "Enabled"
    noncurrent_version_transition {
      noncurrent_days = 30
      storage_class   = "STANDARD_IA"
    }
    noncurrent_version_expiration {
      noncurrent_days = 365
    }
  }
}

###############################################################################
# Outputs
###############################################################################
output "alb_arn"                  { value = aws_lb.this.arn }
output "alb_dns_name"             { value = aws_lb.this.dns_name }
output "alb_security_group_id"    { value = aws_security_group.alb.id }
output "api_target_group_arn"       { value = aws_lb_target_group.api.arn }
output "ws_target_group_arn"        { value = aws_lb_target_group.ws.arn }
output "dashboard_target_group_arn" { value = aws_lb_target_group.dashboard.arn }
output "bridge_target_group_arn"    { value = aws_lb_target_group.bridge.arn }
output "s3_bucket_name"             { value = aws_s3_bucket.novu.bucket }
output "s3_bucket_arn"              { value = aws_s3_bucket.novu.arn }
