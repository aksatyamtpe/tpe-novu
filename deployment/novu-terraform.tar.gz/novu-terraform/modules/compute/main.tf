###############################################################################
# Compute module — ECS Fargate cluster + service per Novu component
###############################################################################

terraform {
  required_version = ">= 1.6"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.60" }
  }
}

variable "name_prefix"         { type = string }
variable "vpc_id"              { type = string }
variable "app_subnet_ids"      { type = list(string) }
variable "alb_security_group_id" { type = string }
variable "kms_key_arn"         { type = string }
variable "secret_arns"         { type = map(string) }   # from secrets module
variable "image_repository"    { type = string }        # ECR repo URI
variable "novu_version"        { type = string  default = "2.3.0" }
variable "bridge_image"        { type = string }        # full image URI for the team's Bridge build
variable "host_name"           { type = string }
variable "front_base_url"      { type = string }
variable "api_root_url"        { type = string }
variable "ws_public_url"       { type = string }
variable "bridge_public_url"   { type = string }
variable "log_retention_days"  { type = number  default = 90 }
variable "tags"                { type = map(string)  default = {} }

###############################################################################
# Cluster
###############################################################################
resource "aws_ecs_cluster" "this" {
  name = "${var.name_prefix}-cluster"
  setting {
    name  = "containerInsights"
    value = "enabled"
  }
  tags = var.tags
}

resource "aws_ecs_cluster_capacity_providers" "this" {
  cluster_name       = aws_ecs_cluster.this.name
  capacity_providers = ["FARGATE", "FARGATE_SPOT"]
  default_capacity_provider_strategy {
    capacity_provider = "FARGATE"
    weight            = 1
  }
}

###############################################################################
# Security group for tasks — accepts traffic from ALB only
###############################################################################
resource "aws_security_group" "tasks" {
  name        = "${var.name_prefix}-tasks-sg"
  description = "ECS task ingress from ALB only"
  vpc_id      = var.vpc_id

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = var.tags
}

resource "aws_security_group_rule" "tasks_from_alb" {
  for_each                 = toset(["3000", "3002", "4000", "4001"])
  security_group_id        = aws_security_group.tasks.id
  type                     = "ingress"
  from_port                = tonumber(each.key)
  to_port                  = tonumber(each.key)
  protocol                 = "tcp"
  source_security_group_id = var.alb_security_group_id
  description              = "ALB to task port ${each.key}"
}

###############################################################################
# Task execution role (used by ECS to pull from ECR, write logs, read secrets)
###############################################################################
resource "aws_iam_role" "task_execution" {
  name = "${var.name_prefix}-task-execution"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
  tags = var.tags
}

resource "aws_iam_role_policy_attachment" "task_execution_managed" {
  role       = aws_iam_role.task_execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

resource "aws_iam_role_policy" "task_execution_secrets" {
  role = aws_iam_role.task_execution.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["secretsmanager:GetSecretValue"]
        Resource = values(var.secret_arns)
      },
      {
        Effect   = "Allow"
        Action   = ["kms:Decrypt"]
        Resource = var.kms_key_arn
      }
    ]
  })
}

###############################################################################
# Task role per service — least privilege at runtime
###############################################################################
resource "aws_iam_role" "api_task" {
  name = "${var.name_prefix}-api-task"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role" "worker_task" {
  name = "${var.name_prefix}-worker-task"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

# Worker needs SES + SNS publish for default providers
resource "aws_iam_role_policy" "worker_providers" {
  role = aws_iam_role.worker_task.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["ses:SendEmail", "ses:SendRawEmail"]
        Resource = "*"
      },
      {
        Effect   = "Allow"
        Action   = ["sns:Publish"]
        Resource = "*"
      },
      {
        Effect   = "Allow"
        Action   = ["s3:GetObject", "s3:PutObject"]
        Resource = "${var.s3_bucket_arn}/*"
      }
    ]
  })
}

variable "s3_bucket_arn" { type = string }

###############################################################################
# CloudWatch log groups — one per service
###############################################################################
resource "aws_cloudwatch_log_group" "service" {
  for_each          = toset(["api", "worker", "ws", "dashboard", "bridge"])
  name              = "/ecs/${var.name_prefix}/${each.key}"
  retention_in_days = var.log_retention_days
  kms_key_id        = var.kms_key_arn
  tags              = var.tags
}

###############################################################################
# Common environment block
###############################################################################
locals {
  common_env = [
    { name = "NODE_ENV",                value = "production" },
    { name = "API_ROOT_URL",            value = var.api_root_url },
    { name = "FRONT_BASE_URL",          value = var.front_base_url },
    { name = "HOST_NAME",               value = var.host_name },
    { name = "MONGO_MIN_POOL_SIZE",     value = "10" },
    { name = "MONGO_MAX_POOL_SIZE",     value = "50" },
    { name = "DISABLE_USER_REGISTRATION", value = "true" },
  ]

  common_secrets = [
    { name = "JWT_SECRET",            valueFrom = var.secret_arns.jwt },
    { name = "STORE_ENCRYPTION_KEY",  valueFrom = var.secret_arns.store_key },
    { name = "NOVU_SECRET_KEY",       valueFrom = var.secret_arns.novu_key },
    { name = "MONGO_URL",             valueFrom = var.secret_arns.mongo },
    { name = "REDIS_PASSWORD",        valueFrom = var.secret_arns.redis_queue },
    { name = "REDIS_CACHE_PASSWORD",  valueFrom = var.secret_arns.redis_cache },
  ]
}

###############################################################################
# api service
###############################################################################
resource "aws_ecs_task_definition" "api" {
  family                   = "${var.name_prefix}-api"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 1024
  memory                   = 2048
  execution_role_arn       = aws_iam_role.task_execution.arn
  task_role_arn            = aws_iam_role.api_task.arn

  container_definitions = jsonencode([{
    name      = "api"
    image     = "ghcr.io/novuhq/novu/api:${var.novu_version}"
    essential = true
    portMappings = [{ containerPort = 3000, protocol = "tcp" }]
    environment  = concat(local.common_env, [
      { name = "PORT", value = "3000" }
    ])
    secrets    = local.common_secrets
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = aws_cloudwatch_log_group.service["api"].name
        awslogs-region        = data.aws_region.current.name
        awslogs-stream-prefix = "api"
      }
    }
    healthCheck = {
      command     = ["CMD-SHELL", "wget --quiet --spider http://localhost:3000/v1/health-check || exit 1"]
      interval    = 30
      timeout     = 5
      retries     = 3
      startPeriod = 60
    }
  }])

  tags = var.tags
}

variable "api_target_group_arn"       { type = string }
variable "ws_target_group_arn"        { type = string }
variable "dashboard_target_group_arn" { type = string }
variable "bridge_target_group_arn"    { type = string }

resource "aws_ecs_service" "api" {
  name             = "${var.name_prefix}-api"
  cluster          = aws_ecs_cluster.this.id
  task_definition  = aws_ecs_task_definition.api.arn
  desired_count    = 2
  launch_type      = "FARGATE"
  platform_version = "LATEST"

  network_configuration {
    subnets         = var.app_subnet_ids
    security_groups = [aws_security_group.tasks.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = var.api_target_group_arn
    container_name   = "api"
    container_port   = 3000
  }

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }
  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200

  tags = var.tags
}

# Auto-scaling: api on CPU + RequestCountPerTarget
resource "aws_appautoscaling_target" "api" {
  max_capacity       = 20
  min_capacity       = 2
  resource_id        = "service/${aws_ecs_cluster.this.name}/${aws_ecs_service.api.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  service_namespace  = "ecs"
}

resource "aws_appautoscaling_policy" "api_cpu" {
  name               = "${var.name_prefix}-api-cpu"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.api.resource_id
  scalable_dimension = aws_appautoscaling_target.api.scalable_dimension
  service_namespace  = aws_appautoscaling_target.api.service_namespace

  target_tracking_scaling_policy_configuration {
    target_value = 60
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
    scale_in_cooldown  = 300
    scale_out_cooldown = 60
  }
}

###############################################################################
# worker service
###############################################################################
resource "aws_ecs_task_definition" "worker" {
  family                   = "${var.name_prefix}-worker"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 1024
  memory                   = 2048
  execution_role_arn       = aws_iam_role.task_execution.arn
  task_role_arn            = aws_iam_role.worker_task.arn

  container_definitions = jsonencode([{
    name      = "worker"
    image     = "ghcr.io/novuhq/novu/worker:${var.novu_version}"
    essential = true
    environment  = concat(local.common_env, [
      { name = "PORT", value = "3004" }
    ])
    secrets    = local.common_secrets
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = aws_cloudwatch_log_group.service["worker"].name
        awslogs-region        = data.aws_region.current.name
        awslogs-stream-prefix = "worker"
      }
    }
  }])
  tags = var.tags
}

resource "aws_ecs_service" "worker" {
  name             = "${var.name_prefix}-worker"
  cluster          = aws_ecs_cluster.this.id
  task_definition  = aws_ecs_task_definition.worker.arn
  desired_count    = 2
  launch_type      = "FARGATE"

  network_configuration {
    subnets         = var.app_subnet_ids
    security_groups = [aws_security_group.tasks.id]
    assign_public_ip = false
  }

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  # Graceful shutdown for in-flight BullMQ jobs
  enable_execute_command = true
  tags                   = var.tags
}

# Worker auto-scales on a custom CloudWatch metric (queue depth) — alarm wired in observability module
resource "aws_appautoscaling_target" "worker" {
  max_capacity       = 30
  min_capacity       = 2
  resource_id        = "service/${aws_ecs_cluster.this.name}/${aws_ecs_service.worker.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  service_namespace  = "ecs"
}

###############################################################################
# ws service (sticky)
###############################################################################
resource "aws_ecs_task_definition" "ws" {
  family                   = "${var.name_prefix}-ws"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 1024
  memory                   = 2048
  execution_role_arn       = aws_iam_role.task_execution.arn
  task_role_arn            = aws_iam_role.api_task.arn

  container_definitions = jsonencode([{
    name      = "ws"
    image     = "ghcr.io/novuhq/novu/ws:${var.novu_version}"
    essential = true
    portMappings = [{ containerPort = 3002, protocol = "tcp" }]
    environment  = concat(local.common_env, [
      { name = "PORT",            value = "3002" },
      { name = "WS_CONTEXT_PATH", value = "" }
    ])
    secrets    = local.common_secrets
    ulimits = [{ name = "nofile", softLimit = 65536, hardLimit = 65536 }]
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = aws_cloudwatch_log_group.service["ws"].name
        awslogs-region        = data.aws_region.current.name
        awslogs-stream-prefix = "ws"
      }
    }
  }])
  tags = var.tags
}

resource "aws_ecs_service" "ws" {
  name             = "${var.name_prefix}-ws"
  cluster          = aws_ecs_cluster.this.id
  task_definition  = aws_ecs_task_definition.ws.arn
  desired_count    = 2
  launch_type      = "FARGATE"

  network_configuration {
    subnets         = var.app_subnet_ids
    security_groups = [aws_security_group.tasks.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = var.ws_target_group_arn
    container_name   = "ws"
    container_port   = 3002
  }
  tags = var.tags
}

###############################################################################
# dashboard service
###############################################################################
resource "aws_ecs_task_definition" "dashboard" {
  family                   = "${var.name_prefix}-dashboard"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 512
  memory                   = 1024
  execution_role_arn       = aws_iam_role.task_execution.arn
  task_role_arn            = aws_iam_role.api_task.arn

  container_definitions = jsonencode([{
    name      = "dashboard"
    image     = "ghcr.io/novuhq/novu/dashboard:${var.novu_version}"
    essential = true
    portMappings = [{ containerPort = 4000, protocol = "tcp" }]
    environment = [
      { name = "NEXT_PUBLIC_API_HOSTNAME",       value = var.api_root_url },
      { name = "NEXT_PUBLIC_WEBSOCKET_HOSTNAME", value = var.ws_public_url },
      { name = "NEXT_PUBLIC_NOVU_SELF_HOSTED",   value = "true" },
      { name = "NEXT_PUBLIC_SELF_HOSTED_TUNNEL", value = "${var.bridge_public_url}/api/novu" }
    ]
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = aws_cloudwatch_log_group.service["dashboard"].name
        awslogs-region        = data.aws_region.current.name
        awslogs-stream-prefix = "dashboard"
      }
    }
  }])
  tags = var.tags
}

resource "aws_ecs_service" "dashboard" {
  name             = "${var.name_prefix}-dashboard"
  cluster          = aws_ecs_cluster.this.id
  task_definition  = aws_ecs_task_definition.dashboard.arn
  desired_count    = 2
  launch_type      = "FARGATE"

  network_configuration {
    subnets         = var.app_subnet_ids
    security_groups = [aws_security_group.tasks.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = var.dashboard_target_group_arn
    container_name   = "dashboard"
    container_port   = 4000
  }
  tags = var.tags
}

###############################################################################
# bridge service (team's own image)
###############################################################################
resource "aws_ecs_task_definition" "bridge" {
  family                   = "${var.name_prefix}-bridge"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 512
  memory                   = 1024
  execution_role_arn       = aws_iam_role.task_execution.arn
  task_role_arn            = aws_iam_role.api_task.arn

  container_definitions = jsonencode([{
    name      = "bridge"
    image     = var.bridge_image
    essential = true
    portMappings = [{ containerPort = 4001, protocol = "tcp" }]
    environment = [
      { name = "NOVU_API_URL", value = var.api_root_url },
      { name = "PORT",         value = "4001" }
    ]
    secrets = [
      { name = "NOVU_SECRET_KEY", valueFrom = var.secret_arns.novu_key }
    ]
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = aws_cloudwatch_log_group.service["bridge"].name
        awslogs-region        = data.aws_region.current.name
        awslogs-stream-prefix = "bridge"
      }
    }
  }])
  tags = var.tags
}

resource "aws_ecs_service" "bridge" {
  name             = "${var.name_prefix}-bridge"
  cluster          = aws_ecs_cluster.this.id
  task_definition  = aws_ecs_task_definition.bridge.arn
  desired_count    = 2
  launch_type      = "FARGATE"

  network_configuration {
    subnets         = var.app_subnet_ids
    security_groups = [aws_security_group.tasks.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = var.bridge_target_group_arn
    container_name   = "bridge"
    container_port   = 4001
  }
  tags = var.tags
}

data "aws_region" "current" {}

###############################################################################
# Outputs
###############################################################################
output "cluster_name"          { value = aws_ecs_cluster.this.name }
output "tasks_security_group"  { value = aws_security_group.tasks.id }
output "service_names" {
  value = {
    api       = aws_ecs_service.api.name
    worker    = aws_ecs_service.worker.name
    ws        = aws_ecs_service.ws.name
    dashboard = aws_ecs_service.dashboard.name
    bridge    = aws_ecs_service.bridge.name
  }
}
