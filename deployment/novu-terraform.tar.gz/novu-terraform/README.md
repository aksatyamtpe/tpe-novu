# Novu Terraform — Track A Production Reference Architecture

Composable Terraform modules implementing the Track A multi-AZ architecture
described in the deployment guide. Provisions:

- VPC across 2 AZs in `ap-south-1` with public, private-app, and private-data
  subnets, NAT gateways per AZ, VPC endpoints (S3, ECR, Secrets Manager, KMS,
  Logs, SSM), and Flow Logs to CloudWatch.
- KMS CMK + Secrets Manager entries for JWT, `STORE_ENCRYPTION_KEY`,
  `NOVU_SECRET_KEY`, MongoDB credentials, Redis AUTH tokens, and provider keys.
- DocumentDB cluster (or swap for MongoDB Atlas — see Adapt section).
- Two ElastiCache replication groups (queue + cache), Multi-AZ, AUTH-enabled,
  encrypted in transit and at rest.
- Application Load Balancer with ACM TLS, path-based routing, access logs,
  AWS WAF v2 (Common + KnownBadInputs + IPReputation + custom rate limit on
  the trigger endpoint), and Route 53 alias record.
- ECS Fargate cluster running api / worker / ws / dashboard / bridge as
  separate services, each with its own task role, log group, and auto-scaling.
- CloudWatch alarms wired to an SNS topic for paging.
- S3 bucket for attachments with KMS, versioning, public access block, and
  lifecycle rules.

## Prerequisites

| Tool       | Minimum  | Notes |
|------------|----------|-------|
| Terraform  | 1.6      | Required for the `import` block syntax used in some patterns |
| AWS CLI v2 | 2.13+    | For state-bucket creation and OIDC IAM setup |
| AWS account | —       | Region: `ap-south-1` |
| Route 53 hosted zone | — | For the public hostname (e.g. `novu.example.com`) |
| Bridge image | —     | Built from the `bridge/` folder of the CE bundle, pushed to ECR |
| State backend | —    | S3 bucket + DynamoDB lock table (created out-of-band before `terraform init`) |

## Folder layout

```
novu-terraform/
├── README.md                    ← you are here
├── modules/
│   ├── network/                 ← VPC, subnets, NAT, endpoints, flow logs
│   ├── secrets/                 ← KMS CMK + Secrets Manager + generated values
│   ├── data/                    ← DocumentDB + ElastiCache (queue + cache)
│   ├── compute/                 ← ECS cluster + 5 service definitions
│   ├── edge/                    ← ALB + ACM + WAF + Route 53 + S3
│   └── observability/           ← CloudWatch alarms, log filters, SNS topic
└── envs/
    ├── dev/                     ← dev environment composition (cost-tuned)
    └── prd/                     ← prod environment composition (HA)
```

## Bootstrap and apply

```bash
# 1) One-time: state bucket + lock table (do this before terraform init)
aws s3api create-bucket \
  --bucket your-tf-state-novu --region ap-south-1 \
  --create-bucket-configuration LocationConstraint=ap-south-1
aws s3api put-bucket-versioning \
  --bucket your-tf-state-novu \
  --versioning-configuration Status=Enabled
aws dynamodb create-table \
  --table-name your-tf-locks --region ap-south-1 \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST

# Update the backend block in envs/prd/main.tf (and dev) with the names above.

# 2) Plan and apply per environment
cd envs/prd
terraform init
terraform plan -var alarm_email=oncall@example.com -var route53_zone_id=ZXXXXXXXX
terraform apply
```

## After apply — manual steps

The Terraform leaves three things deliberately manual because they require
out-of-band action (DLT registration, SES production access, FCM project
setup, MongoDB user creation, etc.):

1. **MongoDB connection string**: After DocumentDB is up, populate the
   `MONGO_URL` Secrets Manager secret with the full connection URI (including
   the master password from the `module.data` output).
2. **Provider credentials**: Populate the `provider-ses`, `provider-msg91`,
   `provider-fcm` secrets with real values from the respective admin UIs.
3. **First admin account**: Browse to the dashboard URL, register the first
   admin, then immediately set `DISABLE_USER_REGISTRATION=true` (already
   defaulted in the task definition; verify in the running task).
4. **Bridge image**: Build and push the team's Bridge image to ECR; pass the
   resulting URI as `-var bridge_image=<URI>` on apply.

## Adapt — MongoDB Atlas instead of DocumentDB

DocumentDB is API-compatible, not a drop-in MongoDB. Some Novu features have
caused incidents on DocumentDB historically. To use Atlas instead:

1. Replace `modules/data/main.tf` DocumentDB resources with
   `mongodbatlas_cluster` resources from the
   [MongoDB Atlas Terraform provider](https://registry.terraform.io/providers/mongodb/mongodbatlas).
2. Establish VPC peering between the Atlas project network and the workload VPC.
3. Output the Atlas SRV connection string into the same `MONGO_URL` Secrets
   Manager secret.

The compute and edge modules are unchanged — they just consume the connection
string from Secrets Manager.

## Module dependency graph

```
network → secrets → edge ──┐
                            ├─→ compute → observability
                       data ┘
```

`data` depends on `compute` for the app security group ID (Redis and
DocumentDB security groups need to allow ingress from the ECS task SG).
`compute` depends on `edge` for the target group ARNs and ALB security group
ID. This produces a slight cycle in the graph, resolved by deploying `edge`
first, then `compute`, then `data` (in `dev/prd/main.tf` the modules are
declared in this order; Terraform handles the rest via implicit dependencies).

## Cost — see Section 32 of the deployment guide

Anticipated monthly cost for prd at low-volume (< 25 ev/s sustained):
~₹140k–₹200k excluding provider per-message charges.

## Caveats and known limitations

- **No multi-region**. Single-region (ap-south-1) deployment. For DR strategy
  see Section 33 of the deployment guide.
- **No Spot for worker in prd**. Worker uses on-demand Fargate. To use Spot
  in dev, change `aws_ecs_service.worker` to use a `capacity_provider_strategy`
  block with `FARGATE_SPOT`.
- **WAF rate limits are conservative**. Tune `trigger_rate_limit_per_5min_per_ip`
  based on observed legitimate burst.
- **Bridge endpoint is restricted to `10.0.0.0/8`** by default. Adjust
  `bridge_allowed_cidrs` in the edge module before apply if your corporate
  VPN exits from a different range.
- **Migrations are NOT run by Terraform**. Database migrations follow the
  runbook in Section 7 of the deployment guide and require source-tree access.
