/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  output: 'standalone',
  // The Bridge endpoint must be reachable by the Novu API/Worker container.
  // In compose, that's `http://bridge:4001/api/novu`.
};
module.exports = nextConfig;
