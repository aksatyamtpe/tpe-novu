"""
Track A — Multi-AZ Production Architecture (v3)

Layout:
  y=2-5:   Observability bar (NOT in any VPC)
  y=8-14:  Atlas peered VPC (10.42.0.0/16) + S3 (regional) — OUTSIDE customer VPC
  y=16-58: Customer VPC (10.40.0.0/16)
    y=18-26: Private data subnets (Redis, Secrets, KMS — Atlas removed since external)
    y=29-47: Private app subnets (ECS, Bridge, VPC endpoints in BOTH AZs)
    y=49-57: Public subnets (WAF + ALB integrated, NAT GWs, SSM endpoint)
  y=61-64: Internet Gateway
  y=66-69: Internet
  y=72-74: Title
"""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle

NAVY = '#0B2545'; NAVY_DARK = '#061A33'; TEAL = '#13856B'; TEAL_LIGHT = '#D1ECE2'
AMBER = '#B45309'; AMBER_LIGHT = '#FEF3C7'
GREY = '#E5E7EB'; GREY_DARK = '#6B7280'
WHITE = '#FFFFFF'; BLACK = '#111827'; BG = '#FAFAFA'
PEERED_BG = '#F0F9FF'

fig, ax = plt.subplots(figsize=(16, 12.5), dpi=150)
ax.set_xlim(0, 100); ax.set_ylim(0, 76); ax.set_aspect('equal'); ax.axis('off')
fig.patch.set_facecolor(WHITE)

def box(x, y, w, h, label, sublabel=None, fill=WHITE, edge=NAVY, text_color=BLACK,
        rounded=True, lw=1.5, label_size=9, sublabel_size=7, label_weight='bold'):
    if rounded:
        patch = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05,rounding_size=0.4",
                                linewidth=lw, edgecolor=edge, facecolor=fill, zorder=2)
    else:
        patch = Rectangle((x, y), w, h, linewidth=lw, edgecolor=edge, facecolor=fill, zorder=2)
    ax.add_patch(patch)
    if sublabel:
        ax.text(x + w/2, y + h/2 + 0.6, label, ha='center', va='center',
                fontsize=label_size, color=text_color, weight=label_weight, zorder=3)
        ax.text(x + w/2, y + h/2 - 0.8, sublabel, ha='center', va='center',
                fontsize=sublabel_size, color=text_color, zorder=3)
    else:
        ax.text(x + w/2, y + h/2, label, ha='center', va='center',
                fontsize=label_size, color=text_color, weight=label_weight, zorder=3)

def arrow(x1, y1, x2, y2, color=GREY_DARK, lw=1.0, style='-|>', alpha=0.7, linestyle='-'):
    a = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=10,
                        color=color, linewidth=lw, alpha=alpha, zorder=1, linestyle=linestyle)
    ax.add_patch(a)

def label_zone(x, y, w, h, text, fill, edge, text_color=NAVY, linestyle='--', alpha=0.4,
               label_offset_y=1.2, label_offset_x=0.6):
    patch = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.1,rounding_size=0.3",
                            linewidth=1.5, edgecolor=edge, facecolor=fill,
                            linestyle=linestyle, alpha=alpha, zorder=0)
    ax.add_patch(patch)
    ax.text(x + label_offset_x, y + h - label_offset_y, text, ha='left', va='top',
            fontsize=8, color=text_color, weight='bold', zorder=1)

# ============================================================
# Title
# ============================================================
ax.text(50, 73.5, 'Track A — Multi-AZ Production Architecture (ap-south-1)',
        ha='center', va='center', fontsize=15, color=NAVY, weight='bold')
ax.text(50, 71.2, 'VPC 10.40.0.0/16  •  ECS Fargate  •  Managed Mongo + ElastiCache',
        ha='center', va='center', fontsize=9, color=GREY_DARK, style='italic')

# ============================================================
# Internet (top)
# ============================================================
box(40, 66, 20, 3, 'Internet', sublabel='Customer apps, mobile clients',
    fill=GREY, edge=GREY_DARK, label_size=10)

# ============================================================
# Internet Gateway (between Internet and customer VPC)
# ============================================================
box(43, 61.6, 14, 2.4, 'Internet Gateway', sublabel='igw-novu-prd',
    fill=TEAL_LIGHT, edge=TEAL, label_size=8.5, sublabel_size=7)
arrow(50, 66, 50, 64, color=NAVY, lw=1.8)

# ============================================================
# Customer VPC outer container — y=16 to y=60
# ============================================================
label_zone(2, 16, 96, 44, 'VPC  ap-south-1  (10.40.0.0/16) — customer-managed', BG, NAVY)
arrow(50, 61.6, 50, 60, color=NAVY, lw=1.8)

# ============================================================
# Public subnets — top of customer VPC, y=49 to y=57
# ============================================================
label_zone(4, 49, 92, 8, 'Public subnets  (ap-south-1a + ap-south-1b)', WHITE, TEAL)

# ALB band (with WAF as integrated label inside)
box(20, 50.5, 32, 5.4, 'Application Load Balancer  •  WAF v2 attached',
    sublabel='ACM TLS 1.2+ • path routing • access logs\nWAF managed rules: Common + KnownBad + IP reputation',
    fill=TEAL_LIGHT, edge=TEAL, label_size=9.5, sublabel_size=6.5)

# NAT GWs
box(58, 51, 9, 4.4, 'NAT GW', sublabel='ap-south-1a',
    fill=GREY, edge=GREY_DARK, label_size=8)
box(70, 51, 9, 4.4, 'NAT GW', sublabel='ap-south-1b',
    fill=GREY, edge=GREY_DARK, label_size=8)
box(82, 51, 13, 4.4, 'AWS Systems Mgr',
    sublabel='Session Manager (admin)\nvia VPC endpoint',
    fill=GREY, edge=GREY_DARK, label_size=7.5, sublabel_size=6.5)

# IGW → ALB indicator (short connector inside zone)
arrow(50, 60, 50, 56, color=NAVY, lw=1.5)

# ============================================================
# Private app subnets — y=29 to y=47
# ============================================================
label_zone(4, 29, 45, 18, 'Private app subnets — AZ ap-south-1a', WHITE, NAVY)
label_zone(51, 29, 45, 18, 'Private app subnets — AZ ap-south-1b', WHITE, NAVY)

y_tasks = 39
# AZ-1a tasks
box(6, y_tasks, 9, 5, 'api', sublabel='2× 1vCPU\n/ 2GiB', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=9, sublabel_size=7)
box(17, y_tasks, 9, 5, 'worker', sublabel='2× 1vCPU\n/ 2GiB', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=9, sublabel_size=7)
box(28, y_tasks, 9, 5, 'ws', sublabel='2× 1vCPU\n/ 2GiB', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=9, sublabel_size=7)
box(39, y_tasks, 8, 5, 'dashboard', sublabel='1× 0.5vCPU\n/ 1GiB', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=8, sublabel_size=7)

# AZ-1b tasks (mirror)
box(53, y_tasks, 9, 5, 'api', sublabel='2× 1vCPU\n/ 2GiB', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=9, sublabel_size=7)
box(64, y_tasks, 9, 5, 'worker', sublabel='2× 1vCPU\n/ 2GiB', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=9, sublabel_size=7)
box(75, y_tasks, 9, 5, 'ws', sublabel='2× 1vCPU\n/ 2GiB', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=9, sublabel_size=7)
box(86, y_tasks, 8, 5, 'dashboard', sublabel='1× 0.5vCPU\n/ 1GiB', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=8, sublabel_size=7)

# Bridge per-AZ
box(6, 31, 13, 4, 'Bridge service', sublabel='Code-first endpoint',
    fill=TEAL_LIGHT, edge=TEAL, label_size=8.5, sublabel_size=6.5)
box(53, 31, 13, 4, 'Bridge service', sublabel='Code-first endpoint',
    fill=TEAL_LIGHT, edge=TEAL, label_size=8.5, sublabel_size=6.5)

# VPC Endpoints — IN BOTH AZs (correct HA)
box(21, 31, 14, 4, 'VPC Endpoints (1a)', sublabel='ECR/SM/KMS/Logs/S3',
    fill=GREY, edge=GREY_DARK, label_size=8, sublabel_size=6.5)
box(68, 31, 14, 4, 'VPC Endpoints (1b)', sublabel='ECR/SM/KMS/Logs/S3',
    fill=GREY, edge=GREY_DARK, label_size=8, sublabel_size=6.5)

# Amazon ECR (regional — accessed via VPC endpoints)
box(36, 31, 12, 4, 'Amazon ECR', sublabel='shared (AWS-mgd)',
    fill=GREY, edge=GREY_DARK, label_size=8, sublabel_size=6.5)
box(83, 31, 12, 4, 'AWS Systems Mgr', sublabel='Param Store',
    fill=GREY, edge=GREY_DARK, label_size=7.5, sublabel_size=6.5)

# ============================================================
# Private data subnets — y=18 to y=27
#   ONLY contains things truly inside customer VPC: Redis, Secrets, KMS endpoint
# ============================================================
label_zone(4, 18, 45, 9, 'Private data subnets — AZ ap-south-1a', WHITE, NAVY_DARK)
label_zone(51, 18, 45, 9, 'Private data subnets — AZ ap-south-1b', WHITE, NAVY_DARK)

box(6, 19.5, 18, 5.5, 'ElastiCache  novu-queue',
    sublabel='Redis 7.x  •  AOF on  •  MAZ failover',
    fill=AMBER_LIGHT, edge=AMBER, label_size=8.5, sublabel_size=6.5)
box(53, 19.5, 18, 5.5, 'ElastiCache  novu-cache',
    sublabel='Redis 7.x  •  AOF off  •  LRU + MAZ',
    fill=AMBER_LIGHT, edge=AMBER, label_size=8.5, sublabel_size=6.5)

box(26, 19.5, 22, 5.5, 'AWS Secrets Manager (regional)',
    sublabel='JWT, STORE_KEY, NOVU_KEY, provider keys\nKMS-encrypted, accessed via VPC endpoint',
    fill=GREY, edge=GREY_DARK, label_size=8.5, sublabel_size=6.5)
box(73, 19.5, 22, 5.5, 'AWS KMS — Customer-Managed CMK',
    sublabel='EBS / S3 / Secrets Manager / RDS\nBYOK to Atlas; ElastiCache TLS',
    fill=GREY, edge=GREY_DARK, label_size=8.5, sublabel_size=6.5)

# ============================================================
# OUTSIDE the customer VPC — Atlas (peered) + S3 (regional)
# y=8 to y=14
# ============================================================
label_zone(2, 8, 45, 7, 'MongoDB Atlas Project — peered VPC (10.42.0.0/16)',
           PEERED_BG, AMBER, linestyle='-', alpha=0.6,
           label_offset_y=1.0, label_offset_x=1.0)
box(4, 9, 13, 4, 'Atlas node — 1a',
    sublabel='Primary  •  KMS BYOK', fill=AMBER_LIGHT, edge=AMBER,
    label_size=8, sublabel_size=6.5)
box(18, 9, 13, 4, 'Atlas node — 1b',
    sublabel='Secondary  •  PITR 7d', fill=AMBER_LIGHT, edge=AMBER,
    label_size=8, sublabel_size=6.5)
box(32, 9, 13, 4, 'Atlas node — 1c',
    sublabel='Secondary', fill=AMBER_LIGHT, edge=AMBER,
    label_size=8, sublabel_size=6.5)

# Peering indicator between customer VPC and Atlas VPC
ax.text(50, 14.7, '⇅', ha='center', va='center', fontsize=18, color=AMBER, weight='bold', zorder=3)
ax.text(48.5, 14.7, 'VPC peering', ha='right', va='center', fontsize=8,
        color=AMBER, weight='bold', zorder=3, style='italic')

# S3 — regional, outside customer VPC (accessed via gateway VPC endpoint from inside)
label_zone(50, 8, 47, 7, 'AWS regional services (accessed via VPC endpoint)',
           PEERED_BG, TEAL, linestyle='-', alpha=0.4,
           label_offset_y=1.0, label_offset_x=1.0)
box(52, 9, 43, 4, 'Amazon S3 (ap-south-1)',
    sublabel='novu-prd-attachments  •  KMS-SSE  •  versioning  •  cross-region replication',
    fill=TEAL_LIGHT, edge=TEAL, label_size=8.5, sublabel_size=6.5)

# ============================================================
# Observability bar (bottom)
# ============================================================
box(2, 2, 30, 3, 'CloudWatch Logs + Metrics + Container Insights',
    fill=NAVY, edge=NAVY, text_color=WHITE, label_size=8)
box(34, 2, 30, 3, 'CloudTrail (mgmt + S3 data events)',
    fill=NAVY, edge=NAVY, text_color=WHITE, label_size=8)
box(66, 2, 30, 3, 'PagerDuty / Opsgenie • Sentry (optional)',
    fill=NAVY, edge=NAVY, text_color=WHITE, label_size=8)

# ============================================================
# Arrows — flows
# ============================================================
# ALB → ECS tasks
arrow(30, 50.5, 12, 44, color=TEAL, lw=1.0)
arrow(40, 50.5, 60, 44, color=TEAL, lw=1.0)
arrow(33, 50.5, 32, 44, color=TEAL, lw=0.9)
arrow(38, 50.5, 80, 44, color=TEAL, lw=0.9)
arrow(36, 50.5, 43, 44, color=TEAL, lw=0.9)

# NAT egress (private → NAT GW)
arrow(22, 44, 62, 50.8, color=GREY_DARK, lw=0.8, alpha=0.5, linestyle=':')
arrow(67, 44, 75, 50.8, color=GREY_DARK, lw=0.8, alpha=0.5, linestyle=':')

# api/worker → ElastiCache (queue + cache)
arrow(15, 39, 16, 25, color=AMBER, lw=0.9)
arrow(60, 39, 63, 25, color=AMBER, lw=0.9)
arrow(22, 39, 22, 25, color=AMBER, lw=0.9)
arrow(67, 39, 67, 25, color=AMBER, lw=0.9)

# Worker → Atlas (cross-VPC peering, dashed)
arrow(20, 39, 23, 13.2, color=AMBER, lw=0.9, alpha=0.7, linestyle='--')
arrow(67, 39, 35, 13.2, color=AMBER, lw=0.9, alpha=0.7, linestyle='--')

# ============================================================
# Legend (bottom-right)
# ============================================================
lx, ly = 2, 6.2
ax.add_patch(Rectangle((lx, ly), 96, 1.4, facecolor=WHITE, edgecolor=GREY_DARK, linewidth=0.5, alpha=0.7))
ax.text(lx + 1, ly + 0.7, 'Legend:', va='center', fontsize=7, color=NAVY, weight='bold')

# Color swatches
ax.add_patch(Rectangle((lx + 8, ly + 0.3), 1.2, 0.8, facecolor=NAVY, edgecolor=NAVY))
ax.text(lx + 9.5, ly + 0.7, 'Compute', va='center', fontsize=6.5, color=NAVY)
ax.add_patch(Rectangle((lx + 16, ly + 0.3), 1.2, 0.8, facecolor=AMBER_LIGHT, edgecolor=AMBER))
ax.text(lx + 17.5, ly + 0.7, 'Data', va='center', fontsize=6.5, color=NAVY)
ax.add_patch(Rectangle((lx + 21, ly + 0.3), 1.2, 0.8, facecolor=TEAL_LIGHT, edgecolor=TEAL))
ax.text(lx + 22.5, ly + 0.7, 'Network/Edge', va='center', fontsize=6.5, color=NAVY)
ax.add_patch(Rectangle((lx + 32, ly + 0.3), 1.2, 0.8, facecolor=PEERED_BG, edgecolor=AMBER))
ax.text(lx + 33.5, ly + 0.7, 'External (peered/regional)', va='center', fontsize=6.5, color=NAVY)

# Arrow legend
ax.plot([lx + 53, lx + 56], [ly + 0.7, ly + 0.7],
        color=GREY_DARK, lw=0.8, linestyle=':', alpha=0.7)
ax.text(lx + 56.5, ly + 0.7, 'NAT egress', va='center', fontsize=6.5, color=GREY_DARK)
ax.plot([lx + 67, lx + 70], [ly + 0.7, ly + 0.7],
        color=AMBER, lw=0.9, linestyle='--', alpha=0.7)
ax.text(lx + 70.5, ly + 0.7, 'Cross-VPC (peered)', va='center', fontsize=6.5, color=AMBER)
ax.plot([lx + 83, lx + 86], [ly + 0.7, ly + 0.7],
        color=AMBER, lw=0.9, linestyle='-', alpha=0.7)
ax.text(lx + 86.5, ly + 0.7, 'In-VPC data', va='center', fontsize=6.5, color=AMBER)

plt.savefig('/home/claude/combined-doc/diagrams/track-a-multi-az.png',
            dpi=150, bbox_inches='tight', facecolor=WHITE)
print("Wrote track-a-multi-az.png")
