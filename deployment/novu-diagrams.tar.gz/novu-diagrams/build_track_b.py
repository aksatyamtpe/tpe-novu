"""
Track B — Single-EC2 Pilot Topology (v2)

Fixes from v1:
  - Removed Caddy → worker arrow (worker has NO public HTTP route)
  - Added worker → mongodb arrow (worker writes message + executiondetail)
  - Added EC2 Security Group annotation (inbound 80/443; admin via SSM, no SSH)
  - Added inline note that bridge is internal-only in production posture
"""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

NAVY = '#0B2545'; NAVY_DARK = '#061A33'
TEAL = '#13856B'; TEAL_LIGHT = '#D1ECE2'
AMBER = '#B45309'; AMBER_LIGHT = '#FEF3C7'
GREY = '#E5E7EB'; GREY_DARK = '#6B7280'
WHITE = '#FFFFFF'; BLACK = '#111827'; BG = '#FAFAFA'

fig, ax = plt.subplots(figsize=(14, 9.5), dpi=150)
ax.set_xlim(0, 100); ax.set_ylim(0, 64); ax.set_aspect('equal'); ax.axis('off')
fig.patch.set_facecolor(WHITE)

def box(x, y, w, h, label, sublabel=None, fill=WHITE, edge=NAVY, text_color=BLACK,
        lw=1.5, label_size=10, sublabel_size=8, label_weight='bold'):
    patch = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05,rounding_size=0.4",
                            linewidth=lw, edgecolor=edge, facecolor=fill, zorder=2)
    ax.add_patch(patch)
    if sublabel:
        ax.text(x + w/2, y + h/2 + 0.55, label, ha='center', va='center',
                fontsize=label_size, color=text_color, weight=label_weight, zorder=3)
        ax.text(x + w/2, y + h/2 - 0.95, sublabel, ha='center', va='center',
                fontsize=sublabel_size, color=text_color, zorder=3)
    else:
        ax.text(x + w/2, y + h/2, label, ha='center', va='center',
                fontsize=label_size, color=text_color, weight=label_weight, zorder=3)

def arrow(x1, y1, x2, y2, color=GREY_DARK, lw=1.0, style='-|>', alpha=0.7, linestyle='-'):
    a = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=10,
                        color=color, linewidth=lw, alpha=alpha, zorder=1, linestyle=linestyle)
    ax.add_patch(a)

def zone(x, y, w, h, fill, edge, linestyle='--'):
    patch = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.1,rounding_size=0.3",
                            linewidth=1.5, edgecolor=edge, facecolor=fill,
                            linestyle=linestyle, alpha=0.4, zorder=0)
    ax.add_patch(patch)

def zone_label(x, y, text, color=NAVY, size=10):
    ax.text(x, y, text, ha='left', va='bottom',
            fontsize=size, color=color, weight='bold', zorder=4)

# Title
ax.text(50, 61.5, 'Track B — Single-EC2 Pilot Topology',
        ha='center', va='center', fontsize=17, color=NAVY, weight='bold')
ax.text(50, 59, 'Non-production / sandbox use only  •  Docker Compose  •  All services co-located',
        ha='center', va='center', fontsize=9.5, color=GREY_DARK, style='italic')

# Internet (top)
box(40, 53, 20, 4, 'Internet', sublabel='Customer apps, mobile clients',
    fill=GREY, edge=GREY_DARK, label_size=11, sublabel_size=8.5)

# EC2 zone label ABOVE the box (with security group note)
zone_label(5, 49.6,
    'Amazon EC2 — t3.xlarge   •   Amazon Linux 2023   •   100 GiB gp3 (KMS-encrypted)   •   '
    'Security Group: inbound 80/443; admin via SSM (no SSH)',
    color=NAVY, size=8.5)
zone(5, 6.5, 90, 42.7, BG, NAVY, linestyle='-')

# Caddy reverse proxy (top of EC2)
box(35, 43.5, 30, 4, 'Caddy reverse proxy',
    sublabel="Auto Let's Encrypt TLS   •   ports 80/443",
    fill=TEAL_LIGHT, edge=TEAL, label_size=10.5, sublabel_size=8.5)

# Docker network zone label
zone_label(8, 40.4,
    'Docker network "novu"   •   all ports bound to 127.0.0.1',
    color=NAVY_DARK, size=9.5)
zone(7, 11, 86, 29, WHITE, NAVY_DARK)

# Novu services row
y = 32
box(9, y, 16, 5, 'api', sublabel=':3000', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=12, sublabel_size=9.5)
box(27, y, 16, 5, 'worker', sublabel='no public port', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=12, sublabel_size=9.5)
box(45, y, 16, 5, 'ws', sublabel=':3002 (sticky)', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=12, sublabel_size=9.5)
box(63, y, 16, 5, 'dashboard', sublabel=':4000', fill=NAVY, edge=NAVY,
    text_color=WHITE, label_size=12, sublabel_size=9.5)
box(81, y, 11, 5, 'bridge', sublabel=':4001 (internal)', fill=TEAL_LIGHT, edge=TEAL,
    label_size=12, sublabel_size=8.5)

# Data services row
y = 14
box(9, y, 16, 6, 'mongodb 7.0',
    sublabel='workflows,\nsubscribers, messages',
    fill=AMBER_LIGHT, edge=AMBER, label_size=10.5, sublabel_size=8.5)
box(27, y, 16, 6, 'redis-queue',
    sublabel='BullMQ jobs (AOF on)',
    fill=AMBER_LIGHT, edge=AMBER, label_size=10.5, sublabel_size=8.5)
box(45, y, 16, 6, 'redis-cache',
    sublabel='DAL cache (LRU)',
    fill=AMBER_LIGHT, edge=AMBER, label_size=10.5, sublabel_size=8.5)
box(63, y, 16, 6, 'localstack',
    sublabel='S3 emulator (dev)',
    fill=GREY, edge=GREY_DARK, label_size=10.5, sublabel_size=8.5)
box(81, y, 11, 6, 'volumes',
    sublabel='persisted',
    fill=GREY, edge=GREY_DARK, label_size=10.5, sublabel_size=8.5)

# AWS layer (bottom)
box(5, 1.5, 27, 3.5, 'AWS Secrets Manager', fill=GREY, edge=GREY_DARK, label_size=10)
box(36, 1.5, 27, 3.5, 'AWS KMS (EBS encryption)', fill=GREY, edge=GREY_DARK, label_size=10)
box(67, 1.5, 27, 3.5, 'CloudWatch Agent → Logs',
    fill=NAVY, edge=NAVY, text_color=WHITE, label_size=10)

# ============================================================
# Arrows — public ingress + internal data flows
# ============================================================
# Internet → Caddy
arrow(50, 53, 50, 47.5, color=NAVY, lw=2)

# Caddy → public-facing services (api, ws, dashboard, bridge)
# Worker is INTENTIONALLY EXCLUDED — it has no public HTTP route
arrow(50, 43.5, 17, 37, color=TEAL, lw=1.2)   # → api
arrow(50, 43.5, 53, 37, color=TEAL, lw=1.2)   # → ws
arrow(50, 43.5, 71, 37, color=TEAL, lw=1.2)   # → dashboard
arrow(50, 43.5, 86, 37, color=TEAL, lw=1.2)   # → bridge (internal only in prod posture)

# Internal service → data layer
arrow(17, 32, 17, 20, color=AMBER, lw=1.2)    # api → mongo
arrow(35, 32, 17, 20, color=AMBER, lw=1.0)    # worker → mongo (NEW — worker writes msg + execdetail)
arrow(35, 32, 35, 20, color=AMBER, lw=1.2)    # worker → redis-queue
arrow(35, 32, 53, 20, color=AMBER, lw=1.0)    # worker → redis-cache
arrow(53, 32, 53, 20, color=AMBER, lw=1.2)    # ws → redis-cache

# api → redis-cache (for cache reads)
arrow(17, 32, 53, 20, color=AMBER, lw=0.8, alpha=0.5, linestyle=':')

# bridge ← worker (worker calls bridge for code-defined steps)
arrow(35, 33, 86, 33, color=TEAL, lw=0.9, alpha=0.6, linestyle='--')

# Legend (bottom-right)
ax.text(67, 6.1, 'Legend:', fontsize=8, color=NAVY, weight='bold', va='bottom')
ax.plot([72, 75], [6.3, 6.3], color=TEAL, lw=1.2)
ax.text(75.5, 6.3, 'HTTP (Caddy)', fontsize=7, color=NAVY, va='center')
ax.plot([72, 75], [5.6, 5.6], color=AMBER, lw=1.2)
ax.text(75.5, 5.6, 'In-host data', fontsize=7, color=AMBER, va='center')
ax.plot([85, 88], [6.3, 6.3], color=TEAL, lw=0.9, linestyle='--', alpha=0.6)
ax.text(88.5, 6.3, 'Bridge call', fontsize=7, color=TEAL, va='center')

plt.savefig('/home/claude/combined-doc/diagrams/track-b-single-ec2.png',
            dpi=150, bbox_inches='tight', facecolor=WHITE, pad_inches=0.2)
print("Wrote track-b-single-ec2.png")
