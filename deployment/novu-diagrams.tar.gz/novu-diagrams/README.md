# Novu Architecture & Sequence Diagrams

Standalone high-resolution PNG diagrams for the Novu Notification Engine
Deployment & Operations Guide. Use these in slides, design reviews, or as
embeddable figures elsewhere.

## Contents

| File | Purpose | Source |
|---|---|---|
| `track-a-multi-az.png` | Production multi-AZ AWS topology (ap-south-1) | `build_track_a.py` (matplotlib) |
| `track-b-single-ec2.png` | Single-EC2 pilot/sandbox topology | `build_track_b.py` (matplotlib) |
| `trigger-flow.png` | Trigger API → MongoDB → BullMQ → Worker → Provider → WS sequence | `trigger-flow.mmd` (Mermaid) |
| `bridge-sync.png` | Developer commit → CI → ECS → novu CLI sync sequence | `bridge-sync.mmd` (Mermaid) |
| `data-model.png` | MongoDB collections and primary relationships | `data-model.mmd` (Mermaid ER) |

## Regenerating

For matplotlib-based architecture diagrams (`track-a`, `track-b`):

```bash
python3 build_track_a.py
python3 build_track_b.py
```

For Mermaid-based diagrams:

```bash
npx -p @mermaid-js/mermaid-cli mmdc \
    -i trigger-flow.mmd -o trigger-flow.png \
    -t base -c theme.json -p puppeteer-config.json \
    -w 1784 -H 1133
```

Adjust `-w` and `-H` per diagram.

## Style

All diagrams follow the navy/teal enterprise palette used throughout the
deployment guide: navy `#0B2545`, teal `#13856B`, amber `#B45309` for
warning/sandbox elements.
